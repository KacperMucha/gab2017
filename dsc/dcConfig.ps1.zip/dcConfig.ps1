Configuration InstallDomain {
    Import-DscResource -Module PSDesiredStateConfiguration, xActiveDirectory, cActiveDirectory

        node $AllNodes.Where({$_.Role -in 'DC'}).NodeName {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyAndAutoCorrect'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        $Node.Features.Foreach({
            WindowsFeature $_
            {
                Name = $_
                Ensure = 'Present'
                IncludeAllSubFeature = $true
            }
        })

        xADDomain 'ADDomain' {
            DomainName = $node.DomainName;
            SafemodeAdministratorPassword = $(New-Object System.Management.Automation.PSCredential ("azadmin", $(ConvertTo-SecureString "zxcVBN123$%^" -AsPlainText -Force)))
            DomainAdministratorCredential = $(New-Object System.Management.Automation.PSCredential ("azadmin", $(ConvertTo-SecureString "zxcVBN123$%^" -AsPlainText -Force)))
            DependsOn = '[WindowsFeature]AD-Domain-Services';
        }

        $Node.Accounts.Foreach({
            xADUser $_ {
                Ensure = 'Present'
                DomainName = $Node.DomainName
                UserName = $_
                Enabled = $true
                PasswordNeverExpires = $true
                CannotChangePassword = $true
                Password = $(New-Object System.Management.Automation.PSCredential ("$($Node.DomainName)\$_", $(ConvertTo-SecureString "zxcVBN123$%^" -AsPlainText -Force)))
                DependsOn = '[xADDomain]ADDomain'
            }
        })

        xADGroup CMAdmins {
            Ensure = 'Present'
            GroupName = 'CMAdmins'
            Category = 'Security'
            GroupScope = 'Global'
            Members = 'svc_cminstall', 'cmadmin', 'azadmin'
            DependsOn = '[xADUser]svc_cminstall', '[xADUser]cmadmin'
        }

        xADComputer CM1 {
            Ensure = 'Present'
            ComputerName = 'CM1'
            Enabled = $true
            DependsOn = '[xADDomain]ADDomain'
        }

        xADGroup CMSiteServers {
            Ensure = 'Present'
            GroupName = 'CMSiteServers'
            Category = 'Security'
            GroupScope = 'Global'
            Members = 'CM1$'
            DependsOn = '[xADDomain]ADDomain', '[xADComputer]CM1'
        }

        cADContainer SystemManagement
        {
            Ensure = 'Present'
            ContainerName = 'System Management'
            Path = 'CN=System,DC=corp,DC=lab'
        }

        cADAcl SystemManagementAcl
        {
            Ensure = 'Present'
            Path = 'CN=System Management,CN=System,DC=corp,DC=lab'
            IdentityReference = 'CMSiteServers'
            ActiveDirectoryRight = 'GenericAll'
            AccessControlType = 'Allow'
            ActiveDirectorySecurityInheritance = 'All'
            DependsOn = '[cADContainer]SystemManagement'
        }

        File Resources {
            Ensure = 'Present'
            DestinationPath = 'C:\Resources'
            Type = 'Directory'
        }

        Script extadsch
        {
            SetScript = { Invoke-Command -ScriptBlock { Start-BitsTransfer -Source 'https://raw.github.com/KacperMucha/gab2017/master/bin/extadsch.exe' -Destination 'C:\Resources' } }
            TestScript = { $false }
            GetScript = { }
            DependsOn = '[xADDomain]ADDomain', '[File]Resources'
        }

        Script ExtendADSchema
        {
            SetScript = { Invoke-Command -ScriptBlock { cmd /c C:\Resources\extadsch.exe } }
            TestScript = { $false }
            GetScript = { }
            DependsOn = '[Script]extadsch'
        }
    } #end DC node
}